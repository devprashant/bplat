'use strict';

var mongoose = require('mongoose');

require('../models/cityLandscape');

mongoose.Promise = global.Promise;
